acum= 0
peliculas = {
    "p101": ["luz de otoño", "drama", 110, "B", "español", False],
    "p102": ["noche neon", "accion", 125, "C", "Ingles", True],
    "p103": ["planeta agua", "documental", 90, "A", "Español", False],
    "p104": ["risa total", "comedia", 105, "A", "Español", True],
    "p105": ["codigo zero", "thriller", 118, "C", "Ingles", True],   
    "P106": ["viaje lunar", "ciencia ficcion", 132, "B", "Ingles,", False]
}

cupos = {}
precio = {}
cartelera = {}
cartelera[cupos] = {"P101": [5990, 40],
    "p102": [7990, 0],
    "P103": [4990, 25],
    "P104": [6990, 12],
    "P105": [8990, 8],
    "P106": [7490, 3] }
cartelera[precio] = {"p101": 5000, "p102": 6000, "p103": 4000, "105": 3000, "106": 7000}


def leer_opcion():
    while True:
        
        try: int(input("Ingrese una opcion"))       
             
        except ValueError:
            print("la opcion debe ser ingresada como numero entero")
        break

def menu():
     while True:
        print("========MENU PRINCIPAL========")
        print("1. Cupos por genero")
        print("2. Busqueda de peliculas por rango de precio")
        print("3. Actualizar precio de pelicula")
        print("4. Agregar pelicula")
        print("5. Eliminar pelicula")
        print("6. Salir")
        if leer_opcion == 6:
            break

    
def Cupos_Genero(genero):
    
        genero = int(input("Ingrese un genero de peliculas")).lower
        for x in cartelera:
            if genero == cartelera[x]:                    
                acum = acum+ cartelera[cupos][x]
        print(acum)

def Busqueda_Peliculas():
    Precio_Minimo = input("Ingrese un precio minimo")
    Precio_Maximo = input("Ingrese un precio maximo")
    lista = []
    for i in peliculas:

        if precio >= Precio_Minimo and precio <= Precio_Maximo:
            print()


def Buscar_Codigo(codigo):
    while True:
        codigo = int("Ingrese el codigo de la pelicula")
        if codigo in cartelera:
            PrecioNuevo = input("Ingrese un precio")


        elif codigo not in cartelera: 
            intentar = print("No se encontro el codigo, ¿Desea actualizar otro precio? s/n").slower  
        if intentar == "n":
                break

def Actualizar_Precio(codigo, nuevo_precio):
    del cartelera[precio][codigo][0]
    cartelera[precio][codigo] = [nuevo_precio]

def Agregar_Pelicula():
    titulo = input("Ingrese el titulo")
    codigo = input("Ingrese el codigo")
    genero = input("Ingrese el genero")
    duracion = input("Ingrese la duracion")
    clasificacion = input("Ingrese la clasificacion")
    idioma = input("Ingrese el idioma")
    es_3D = input("¿La pelicula es 3d? n/s")
    Precios_Agregar = input("Ingrese el precio")
    Cupos_Agregar = input("Ingrese los cupos disponibles")
   
    if es_3D == "n":
        es_3D = False
    elif es_3D == "s":
        es_3D = True
    
    peliculas[codigo]=[titulo, genero, duracion, clasificacion, idioma, es_3D]
    cartelera[precio][codigo]=[Precios_Agregar]
    cartelera[cupos][codigo]=[Cupos_Agregar]

def Eliminar_Pelicula(): 
    Buscar_Codigo()
    eliminar = input("el codigo de la pelicula a eliminar")
    del cartelera[cupos][eliminar]
    del cartelera[precio][eliminar]
    del peliculas[eliminar]

def main():
    menu
    leer_opcion()
    if leer_opcion == 1:    
       Cupos_Genero()
    elif leer_opcion == 2:
        Busqueda_Peliculas
    elif leer_opcion == 3:
        Buscar_Codigo()
        Actualizar_Precio()
    elif leer_opcion == 4:
        Eliminar_Pelicula()
    elif leer_opcion == 5:
       Agregar_Pelicula()

if __name__ == "__main__":
    main()
  